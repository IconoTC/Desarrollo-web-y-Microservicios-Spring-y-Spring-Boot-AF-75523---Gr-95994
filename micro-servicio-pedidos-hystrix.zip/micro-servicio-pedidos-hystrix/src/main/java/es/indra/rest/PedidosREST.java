package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import es.indra.business.IPedidosBS;
import es.indra.models.Pedido;
import es.indra.models.Producto;

@RestController
public class PedidosREST {
	
	@Autowired
	// 1ª forma de solucionar es @Primary
	// 2ª forma de solucionar es @Qualifier(nombre_bean)
	@Qualifier("feign")
	private IPedidosBS bs;
	
	// http://localhost:8002/crear/4/cantidad/100
	@GetMapping("/crear/{id}/cantidad/{cantidad}")
	// Podemos implementar un manejo de excepciones globales
	//@HystrixCommand(fallbackMethod = "manejarError")
	public Pedido crear(@PathVariable Long id, @PathVariable int cantidad) {
		return bs.crearPedido(id, cantidad);
	}
	
	// El metodo alternativo ha de tener los mismos argumentos + Throwable
	public Pedido manejarError(Long id, int cantidad, Throwable ex) {
		System.out.println(ex.getMessage() + "**********************");
		System.out.println(ex.getClass() + "**********************");
		
		Producto producto = new Producto();
		producto.setID(id);
		producto.setDescripcion("Producto vacio");
		producto.setPrecio(0);
		
		return new Pedido(producto, cantidad);
	}

}
