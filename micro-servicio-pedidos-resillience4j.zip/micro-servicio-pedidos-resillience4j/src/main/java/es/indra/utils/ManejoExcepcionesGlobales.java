package es.indra.utils;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

@RestControllerAdvice
public class ManejoExcepcionesGlobales {

	// Igual que try-catch podemos tener multiples catch
	// Aqui podemos tener varios metodos donde cada uno captura un tipo de excepcion

	// http://localhost:8002/crear/566556/cantidad/100
	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public ResponseEntity<String> error2(MethodArgumentTypeMismatchException ex) {
		System.out.println("ID debe ser numerico " + ex.getMessage());
		return new ResponseEntity<String>("ID debe ser numerico", HttpStatus.BAD_REQUEST);
	}

	// http://localhost:8002/crear/566556/cantidad/100
	@ExceptionHandler(RuntimeException.class)
	public ResponseEntity<String> error1(RuntimeException ex) {
		System.out.println("ID no valido: " + ex.getMessage());
		return new ResponseEntity<String>("ID no valido", HttpStatus.BAD_REQUEST);
	}

}
