package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import es.indra.clients.ProductosClienteFeign;
import es.indra.models.Pedido;
import es.indra.models.Producto;

// Por defecto, el nombre o el id del bean es el nombre de la clase pero la primera letra en minuscula
@Service("feign") // Ahora el nombre o id del bean es feign
//@Primary   // Estamos dando prioridad en la inyeccion de dependencia
public class PedidosBSImplFeign implements IPedidosBS{
	
	@Autowired
	private ProductosClienteFeign clienteFeign;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		Producto producto = clienteFeign.buscar(id);
		Pedido pedido = new Pedido(producto, cantidad);
		return pedido;
	}

}
