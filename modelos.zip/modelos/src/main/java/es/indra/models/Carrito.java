package es.indra.models;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data // getter, setter, equals, hascode y toString
@NoArgsConstructor // constructor por defecto
@AllArgsConstructor // constructor completo
public class Carrito {

	public String id;
	public String usuario;
	public List<Pedido> contenido = new ArrayList<Pedido>();
	public double importe;

	public Carrito(String usuario, List<Pedido> contenido, double importe) {
		super();
		this.usuario = usuario;
		this.contenido = contenido;
		this.importe = importe;
	}

}
