package es.indra.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data  // getter, setter, equals, hascode y toString
@NoArgsConstructor   // constructor por defecto
@AllArgsConstructor  // constructor completo
public class Pedido {
	
	private Producto producto;
	private int cantidad;

}
