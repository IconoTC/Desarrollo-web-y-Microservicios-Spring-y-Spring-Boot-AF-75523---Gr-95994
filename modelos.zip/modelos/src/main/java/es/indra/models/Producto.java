package es.indra.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data  // getter, setter, equals, hascode y toString
@NoArgsConstructor   // constructor por defecto
@AllArgsConstructor  // constructor completo
public class Producto {
	
	private Long ID;
	private String descripcion;
	private double precio;
	private Integer port;

}
