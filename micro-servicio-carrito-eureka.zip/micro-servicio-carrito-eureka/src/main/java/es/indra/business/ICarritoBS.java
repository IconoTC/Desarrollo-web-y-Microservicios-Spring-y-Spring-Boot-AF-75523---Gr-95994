package es.indra.business;

import es.indra.models.Carrito;

public interface ICarritoBS {
	
	public Carrito crear(String usuario);
	
	public Carrito agregarPedido(Long id, Integer cantidad, String usuario);
	
	public Carrito consultar(String usuario);
	
	public Carrito eliminarPedido(Long id, String usuario);

}
