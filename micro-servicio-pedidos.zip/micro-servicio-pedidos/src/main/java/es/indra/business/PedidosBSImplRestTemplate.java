package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import es.indra.models.Pedido;
import es.indra.models.Producto;

@Service
public class PedidosBSImplRestTemplate implements IPedidosBS{
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		// Buscar el producto con ese id
		Producto producto = restTemplate.getForObject(
				"http://localhost:8001/buscar/{codigo}", Producto.class, id);
		
		// Crear el pedido
		Pedido pedido = new Pedido(producto, cantidad);
		
		// Retonar el pedido
		return pedido;
	}

}
