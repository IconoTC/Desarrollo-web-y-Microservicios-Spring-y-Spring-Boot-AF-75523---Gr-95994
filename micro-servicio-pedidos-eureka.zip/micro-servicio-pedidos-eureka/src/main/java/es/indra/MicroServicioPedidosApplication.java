package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients   // Spring Boot genera un bean de los clientes Feign
@EnableEurekaClient
public class MicroServicioPedidosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioPedidosApplication.class, args);
	}

}
