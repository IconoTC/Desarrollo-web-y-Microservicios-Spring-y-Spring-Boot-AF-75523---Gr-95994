package es.indra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer  // Le indicamos que es el servidor de Eureka
public class MicroServicioEurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioEurekaServerApplication.class, args);
	}

}
